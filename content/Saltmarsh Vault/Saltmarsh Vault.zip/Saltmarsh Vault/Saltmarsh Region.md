![[Saltmarsh Region Map.jpg]]

[[Saltmarsh City]] is located here.

[[Content/Abbey Island]] is just west of [[Saltmarsh City]].

[[Content/Burle]] is the fortified outpost guarding the area from monsters who emerge from the [[Content/Dreadwood]].

The [[Content/Dwarven Mine]] is south of [[Saltmarsh City]] and the [[Content/Haunted Mansion]].

[[Content/Seaton]] is the city that [[Content/King Kimbertos Skotti]] turned into a fortress from which his military forces can attack the [[Content/Sea Princes]].



