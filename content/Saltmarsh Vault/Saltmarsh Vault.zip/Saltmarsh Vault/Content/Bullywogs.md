Frog people who are marauders throughout [[Content/Saltmarsh Swamp]].  They are enemies of the [[Content/Lizardfolk]].  

As [[Content/Collateral Damage]] trudged through [[Content/Saltmarsh Swamp]] they encountered a war party of Bullywogs who had laid a trap.  The party fell into a large pit and the Bullywogs used spears to attack them.  This continued until [[Content/Cleveland Faskettel]] used the spell [[Content/Disguise Self]] to look like a baby Bullywogs.

Upon seeing this baby the Bullywogs climbed into the pit to save this "baby".  The "baby" was given to two of the Bullywog war party to rescue.  This led to a mad cap race through the jungle until [[Content/Cleveland Faskettel]] was taken to the Bullywog's War Chief.

[[Content/Collateral Damage]] defeated the other Bullywogs and chased after [[Content/Cleveland Faskettel]] where they were able to rescue him.

The Bullywog War Chief wore an ornate crown that was taken and worn by [[Content/Grall Silentfoot]] after defeating the War Chief.

The [[Content/War Chief Crown]] has some effect on the wearer.