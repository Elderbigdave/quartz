Saltmarsh was built on the ruins of a much older settlement, sometimes called Old Saltmarsh or the Old Harbor. One sign of this is that the town has a small stretch of wall and a single town gate secured by two or three guards. The wall is old, crumbling, and badly worn by centuries of rain and wind coming in from the Azure Sea.

The garrison at the gate consists of older guards, those nearing retirement and unwilling or unable to walk patrols. Their eyes are sharp, and they are prone to gossip. A pull from a flask of whiskey or a few silver pieces can persuade them to provide information on recent visitors.

#LOCATION 