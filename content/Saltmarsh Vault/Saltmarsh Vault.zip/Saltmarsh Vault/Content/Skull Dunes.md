A vast field of sand dunes at the southern tip of [[Content/Abbey Island]].  Only one special path can allow you to cross without fighting a ton of skeletons.

#LOCATION 