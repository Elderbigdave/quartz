The biggest [[Content/Giff]] in the crew.  He is a known associate of [[Content/Shorty]].

#NPC

