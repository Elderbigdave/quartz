This three-story tower is home to the town’s resident sage and wizard, Keledek the Unspoken (LE male human mage). Keledek’s dusky skin, bald head, and bright red silk turban — not to mention his height of nearly 7 feet — make him an unmistakable figure in town.

Keledek came to town years ago from Ket, a distant kingdom held in a mix of contempt, mistrust, and fear by the locals. Rumor around town claims that speaking his name aloud allows Keledek to eavesdrop on a conversation for a short time. In truth, Keledek relies on his familiar, an imp named Zivmal, to spy on the townsfolk.

Keledek is a close associate of Gellan Primewater. He uses his magic to help a gang of smugglers based out of the nearby Tower of Zenopus in exchange for rare spell components and magic items.

#LOCATION 
