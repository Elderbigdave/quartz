Lives at the [[Content/Lighthouse]].

#NPC 