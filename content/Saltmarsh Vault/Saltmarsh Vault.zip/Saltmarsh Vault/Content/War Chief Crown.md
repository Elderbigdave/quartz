This is a crown worn by [[Content/Grall Silentfoot]] after the defeat of the [[Content/Bullywogs]] War Chief who was the previous owner.

This crown might be cursed as it has caused [[Content/Grall Silentfoot]] to refuse to remove it, even to not allow [[Content/Cleveland Faskettel]] to cast the spell [[Content/Identify]].

After an experience with a time crystal and a semi sentient magical tree the crown changed.