An obscure deity that [[Content/Elden Timbers]] has sworn a warlock pact with, forsaking his original Patreon.

#DIETY
