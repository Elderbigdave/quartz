The Oweland family has owned this sprawling mansion for generations. Despite the family’s wealth, the building is a sprawling collection of new construction, expansions, and additions. Each generation of the family has added to the building to accommodate the clan’s growth. The family takes in fishers who have fallen on hard times, sharing their wealth with others until they can recover.

The sprawling, mazelike interior of the Oweland house has spawned rumors of hidden passages and secret chambers within it. The family once engaged in smuggling, and several hidden tunnels run from the cellars beneath the mansion to points out of town. Skerrin Wavechaser has discovered a few that are unknown even to the family.

#LOCATION 
