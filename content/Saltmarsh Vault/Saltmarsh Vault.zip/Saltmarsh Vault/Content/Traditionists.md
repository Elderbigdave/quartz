Pre-King, old merchants.
Trade-leader
senior town council.
[[Content/Eda Oweland]]

#FACTION 



