A ninja [[Content/Giff]] who has helped [[Content/Collateral Damage]] on several occasions.


#NPC 