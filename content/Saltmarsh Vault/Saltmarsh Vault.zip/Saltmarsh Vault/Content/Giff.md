A tall hippo like humanoid who are helping [[Content/Collateral Damage]] by the command on the [[Content/Guardian of Time]].
