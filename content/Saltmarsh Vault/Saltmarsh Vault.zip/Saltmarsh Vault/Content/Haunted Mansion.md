
![[Content/Haunted Mansion.png]]

This dilapidated building is thought to be haunted but is actually occupied by Pirates. 
People have disappeared near there.
The performers that were going to perform at [[Content/Primewater Mansion]], camped nearby and disappeared, never to be seen again.
It is the house of [[Content/The Alchemist]].
Anyone who survived being near the mansion remember hearing a scary voice and shrieking saying "Get Out!", and "Welcome to Death".

#LOCATION 

