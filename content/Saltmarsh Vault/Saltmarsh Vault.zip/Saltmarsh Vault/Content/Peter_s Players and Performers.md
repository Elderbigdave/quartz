The theatrical troupe alias for [[Content/Collateral Damage]].
They made their theatric debut at [[Content/Primewater's Grand Ball]].
Their are led by [[Content/Peter Snuffencougher]] who uses his illusions to tell stories.
[[Content/Erb Faskettel]] is the groups strong man.
[[Content/Grall Silentfoot]] is the groups acrobat.
[[Content/Rolin]] is the groups animal handler.
[[Content/Lanis]] is the groups artificer.
[[Content/Elden Timbers]] is the groups.....

