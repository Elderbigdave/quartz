The Solmor family owns several buildings in this modest complex. The largest is the personal mansion of the Solmor family. Three smaller buildings house servants, employees of the family’s trading fleet, and secure storage for expensive goods.

The Solmor family maintains a cadre of a dozen guards led by four veterans (all LE humans). These mercenaries report to Skerrin, and though they outwardly serve the Solmors, their loyalty is to the Scarlet Brotherhood.

Despite the Brotherhood’s infiltration of this place, Skerrin takes pains to avoid leaving any incriminating evidence lying about. His eidetic memory allows him to burn any notices and reports he receives after reading them, though at times he can be careless and leave partially burned scraps of paper in his garbage.

#LOCATION 
