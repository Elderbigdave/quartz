*A tavern frequented by the party known as [[Content/Collateral Damage]]. 
[[Content/Winston]] is employed here and is "Haunted" by Ethereal Plane fish.
This tavern is the only tavern in [[Saltmarsh City]]  to serve [[Content/Lobster Claw Wine]].
Several [[Content/Lobster Claw Wine]] drinking contests have been held here, and on occasion [[Content/Grall Silentfoot]] has won.*


This popular inn and tavern is built from the planks and hulls of half a dozen decommissioned fishing ships. Its decor is predictably nautical in theme, and its sleeping rooms are plain but comfortable renditions of a ship’s cabins. The smell of fish has never been scrubbed from its walls, and those who stay the night find their belongings steeped in the scent, which lasts for several days. Sailors and fishers gather here to trade stories and drink into the night.

The Snapping Line is run by a young woman named [[Content/Hanna Rist]] (NG female human commoner), who comes from a family of well-known lobster catchers. The Rist family also makes a spirit from lobster meat and potatoes called claw wine; it is, to put it mildly, an acquired taste. Hanna employs several former dockhands to keep peace in her bar.

#LOCATION 
