[[Content/Cleveland Faskettel]]'s estranged brother 
Barbarian with a deathly fear of maggots
Erb carries [[Content/Collateral Damage]]'s bag of holding 
A deep gnome
Wields a Halberd
Bad haircut
Somewhat hairy and burned
Worked at the docks
Bad with money.
Training to be a sailor by [[Content/Andre]]
Training the be a Blacksmith by.
Member of the party [[Content/Collateral Damage]].
Tormented by [[Content/Shorty]]


#CHARACTER 

