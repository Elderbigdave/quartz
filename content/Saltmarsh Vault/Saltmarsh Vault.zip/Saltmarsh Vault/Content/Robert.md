A veteran guard of [[Content/Eliander Fireborn]].
He is a bigot toward gnomes.
Goes by Bob.

#NPC 
