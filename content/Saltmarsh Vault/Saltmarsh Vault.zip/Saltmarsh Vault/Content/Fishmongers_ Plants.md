The large fish-processing buildings in this area reek of prosperity (and fish). All are engaged in salting or brining the catch brought in by the fleet. Most of the time these places are busy, and the workers have little time for chatter.

#LOCATION 
