Services at this long-standing sea god’s temple are well attended. The congregation is led by a one-legged former whaler: Wellgar Brinehanded (CG male human priest), an older human man with a sharp memory for every storm, lost ship, and enormous catch ever brought into Saltmarsh harbor. He knows many fanciful stories of shipwrecks, lucky escapes, and famous captains. Matters ashore rarely interest him, but the temple and its bell tower are also served by a half-dozen novitiates and laypeople who keep things running smoothly.

Wellgar uses the blessings of [[Content/Procan]] to seek out shipwrecks in order to recover the remains of sailors for a proper burial. He is willing to trade cleric spells of up to 5th level, including raise dead, in return for recovery of the remains he seeks.

#LOCATION 
