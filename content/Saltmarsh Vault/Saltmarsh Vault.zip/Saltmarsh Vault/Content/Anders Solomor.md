Youngest of the council members of [[Saltmarsh City]].

#NPC 

