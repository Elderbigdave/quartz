Silver dragonborn paladin

#CHARACTER 

