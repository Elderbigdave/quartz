The mariners’ guild serves all the towns along the coast, providing a bunk and a meal for sailors passing through. Sea captains in search of a crew stop here, as do others seeking news from afar. The guildhall is an excellent place to discuss seafaring, as well as the various threats to navigation along the coast.

#LOCATION 
