This single large bridge spans the river, with shops and homes along its length. The bridge predates the village and is large enough for laden carts to pass two abreast. Elves and fey folk feel vaguely nauseated when they cross the bridge, owing to an ancient curse placed on it long before Keoland rose to existence.

#LOCATION 
