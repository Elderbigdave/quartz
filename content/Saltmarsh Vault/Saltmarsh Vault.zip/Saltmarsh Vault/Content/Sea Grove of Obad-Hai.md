Open to the air and set in a grove outside town, the sea-grove is a gathering place for seagulls, sailors, and swamp folk, as well as an information market for traders and trappers. Ferrin Kastilar (NG male halfling druid), a somewhat melancholy individual of middle years, tends the shrine with his bullfrog companion, Lorys.

Ferrin always keeps an eye out for rumors of aberrations in the wild. He also has contacts with the elves of the Dreadwood, and they send word to him if a monster escapes that forest and heads in the direction of Saltmarsh. If news of an aberration reaches him, he hires adventurers to stalk and kill the creature.

#LOCATION 
