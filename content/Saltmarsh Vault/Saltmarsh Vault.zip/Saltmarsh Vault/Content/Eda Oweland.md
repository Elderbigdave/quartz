*She owns 3 boats
Right hand to [[Content/Gellan Primewater]]
A member of the [[Content/Traditionists]]
She liked the performance of [[Content/Peter's Players and Performers]].*




Eda (CG female human noble) is the current senior member of the town council, as well as the owner of three large fishing boats. She has lived in Saltmarsh all her life and has been elected to the council three times. She is a gruff, pragmatic woman whose graying hair is cut short and whose face bears the marks of a life lived outdoors. Eda is keenly interested in expanding Saltmarsh’s fishing industry, her sights set on a wild section of the coast where she hopes to build a new dock. She is suspicious of the dwarves’ mining enterprise and doubts it will amount to much.

Personality Traits. Eda swears like a sailor when she is frustrated or angry, and the folk in town who support her appreciate her willingness to stick up for them. Despite her temper, she respects those who keep their cool. Anyone who stands up to her wins her respect. Those who try to flatter her earn her contempt.

Ideal. If anyone in town needs help, Eda is the first to volunteer. She believes community binds people together and allows them to ride out the fiercest storm.

Bond. Saltmarsh is Eda’s home. She would protect it to her dying breath and wants its people to prosper.

Flaw. Eda is suspicious of outsiders, and she is too quick to trust those familiar to her.

#NPC 

