The smallest [[Content/Giff]] and a close companion to [[Content/Lieutenant Hamish]].  He likes to prank [[Content/Erb Faskettel]] with buckets of maggots.
