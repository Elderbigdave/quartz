The blacksmith’s forge has a single anvil with a clear sign of dwarven origins, and a backlog of orders ten miles long. The human smiths make hooks, nails, harpoons, knives, fishing weights, and much more all day. Their master smith is an elderly, dark-skinned woman named Mafera (LG female human commoner); her son, Jasker (LG male human commoner), is her best journeyman. A small shrine to Moradin can be found under the eaves as well, though it is somewhat neglected.

Some of the dwarves associated with the new mining operation would like to know how a human came into ownership of such fine dwarven tools. A few suspect treachery and might hire the characters to break into this place and make off with anything that “rightfully” belongs to the dwarves.

#LOCATION 
