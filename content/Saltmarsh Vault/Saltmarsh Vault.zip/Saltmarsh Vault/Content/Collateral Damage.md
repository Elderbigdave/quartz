Our party of adventurers.

[[Content/Lanis]]
[[Content/Erb Faskettel]]
[[Content/Elden Timbers]]
[[Content/Grall Silentfoot]]
[[Content/Rolin]]
[[Content/Rod]]
[[Content/Perry Stinkmire]]

Gathered together to investigate the mysterious happenings at the old [[Content/Haunted Mansion]] outside of town.

They discovered that the mansion wasn't haunted but occupied by pirates who were using magic to make the mansion seem like it was haunted.

After defeating the pirates in the mansion they tried to tried to trick their way onto the pirate's ship the [[Content/Sea Ghost]]. They defeated the pirates and took control of the ship but didn't know how to sail it and got lost in a storm.

The stolen pirate ship beached onshore a mysterious island that was occupied by [[Content/Giff]] who are serving the [[Content/Guardian of Time]].  The [[Content/Guardian of Time]] asked the party to recover a [[Content/Time Crystal]] from a portal that lead to a strange forest which was playing host to a [[Content/Space Clowns]]'s circus.

With the help of [[Content/Lieutenant Hamish]] a stealthy ninja of a Giff the party were able to escape intact and with the crystal.

The [[Content/Guardian of Time]] sent us away from the island with a [[Content/Giff]] crew that repaired the ship.  Every member of [[Content/Collateral Damage]] forgot about their time on the isle except for [[Content/Cleveland Faskettel]].  

The party of adventurers sailed back to [[Saltmarsh City]] and got ready to head to the [[Content/Saltmarsh Swamp]] to negotiate a treaty between [[Saltmarsh City]] and the [[Content/Lizardfolk]] against the [[Content/Sahuigan]] who are on a rampage in the region because their god is dead.

Rod Joined us later when we embarked on our journey back to [[Content/Saltmarsh Swamp]] to deliver metal weapons to the [[Content/Lizardfolk]].

After giving the weapons to the [[Content/Lizardfolk]] the party was asked to prove their bravery by slaying the legendary [[Content/Thousand Tooth]], a beast deep in the swamps.

After slaying [[Content/Thousand Tooth]] the party returned to the [[Content/Lizardfolk]]'s home to report their success only to discover the [[Content/Lizardfolk]] under attack by [[Content/Sahuigan]].  The party help defeat the [[Content/Sahuigan]] and the [[Content/Lizardfolk]] sign the treaty with [[Saltmarsh City]].

The party returned to [[Saltmarsh City]] and presented the treaty to the city council.  They were then asked to investigate the mysterious [[Content/Abbey Island]].  Before heading there they were instructed to meet with [[Content/Major Ursa]] at the [[Content/Lighthouse]] for more information.

The party just crossed the [[Content/Skull Dunes]] at the southern tip of [[Content/Abbey Island]].  Then they entered the ruins of the abbey.  [[Content/Myrkul]] is the diety of the worshippers within the abbey.

