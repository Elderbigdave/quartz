The diety of the worshippers that dwell within the the abbey on [[Content/Abbey Island]].

He is a God of death, decay, and exhaustion.

#DIETY 



