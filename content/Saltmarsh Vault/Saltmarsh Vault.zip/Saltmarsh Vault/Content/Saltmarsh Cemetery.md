The town’s cemetery is well-kept, but many of its graves are little more than memorial stones laid for those who died at sea. Krag (NG male half-orc commoner) is the town gravedigger, as well as something of a town historian and local loremaster. He has conducted extensive research into the folk buried here and events in the region. He can be an invaluable resource for adventurers seeking information and is especially helpful to those who can help him with his research.

In his spare time, Krag helps organize and translate Eliander’s library. He keeps a room in the guard commander’s home, and the two are close friends.

#LOCATION 
