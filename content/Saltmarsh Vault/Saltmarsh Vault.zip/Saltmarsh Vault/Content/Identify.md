# IDENTIFY

[1st](https://a5e.tools/spell-levels/first)-level ([divination](https://a5e.tools/spells/divination)[arcane](https://a5e.tools/spells/arcane)[knowledge](https://a5e.tools/spells/knowledge))

Class(es)
[Artificer](https://a5e.tools/classes/artificer)
[bard](https://a5e.tools/classes/bard)
[wizard](https://a5e.tools/classes/wizard)
Casting Time
[1 Minute](https://a5e.tools/spell-casting-times/1-minute)
Ritual
Range
[Touch](https://a5e.tools/spell-ranges/touch)
Target
One object or creature
Components:
[V](https://a5e.tools/spell-components/vocalized)[S](https://a5e.tools/spell-components/seen)[M](https://a5e.tools/spell-components/material)
pearl worth at least 100 gold and a feather
Duration:
[Instantaneous](https://a5e.tools/spell-durations/instantaneous)

You learn the target item’s magical properties along with how to use them. This spell also reveals whether or not a targeted item requires attunement and how many charges it has. You learn what spells are affecting the targeted item (if any) along with what spells were used to create it.

Alternatively, you learn any spells that are currently affecting a targeted creature. 

What this spell can reveal is at the Narrator’s discretion, and some powerful and rare magics are immune to _[identify](https://a5e.tools/spell/identify "Click to view a local node.") ._

This spell may be cast as a ritual.

#SPELL 


