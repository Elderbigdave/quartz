A half-elf.
Brother of [[Content/Rolin]]. 
An artificer. 
A student of [[Content/Fizzlepop]].

#CHARACTER 





