[[Content/Peter's Players and Performers]] led by [[Content/Peter Snuffencougher]] went to [[Content/Primewater Mansion]] to audition to perform at [[Content/Gellan Primewater]]'s [[Content/Primewater's Grand Ball]].

There was a servant present named [[Content/Yander]].

There were two judges at the Audition.  An elf and a human Butler named [[Content/Kale Zindit]].

Also Auditioning was a bard named [[Content/Perry Farsmile]].