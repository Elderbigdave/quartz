Brewed by [[Content/Winston]], this "wine" is made of lobster parts.  This unique acquired taste requires it be fermented up to a year.

[[Content/Hanna Rist]] the inn keeper of [[Content/The Snapping Line]] requires [[Content/Winston]] to keep a 10 year stock in the basement.

[[Content/Collateral Damage]] recently took 10 casks on consignment to sell or trade with the [[Content/Lizardfolk]].


