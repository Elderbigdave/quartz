The owner of [[Content/The Snapping Line]].  Long time friend of [[Content/Winston]].

#NPC 