A bard at the [[Content/Primewater Audition]] for [[Content/Primewater's Grand Ball]].
He does not smile.

#NPC 