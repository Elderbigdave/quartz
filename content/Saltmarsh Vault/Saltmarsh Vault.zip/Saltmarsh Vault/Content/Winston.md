Brews [[Content/Lobster Claw Wine]].
Glassy eye
Sees ghosts, and things in the ethereal plane
Works at the [[Content/The Snapping Line]].
Winston has been near the [[Content/Haunted Mansion]] at night and remembers seeing scary flashing lights.

#NPC 