The island where [[Content/Collateral Damage]] met the [[Content/Giff]] and the [[Content/Guardian of Time]].

#LOCATION 
