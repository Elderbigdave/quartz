An alias of [[Content/Cleveland Faskettel]].
Wears an eye patch.
