A strip of open land that is the place for everything that isn’t fish, salt, or nautical wares, this market stretches among a dozen stalls down to the bridge. A few goats, eggs, cloth, marsh plants, and pots are available, as well as the occasional mule or ox for hauling carts.

#LOCATION 
