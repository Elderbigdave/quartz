A female elf who runs the [[Content/Dapper Goose]].

#NPC 
