#### What we know

*Gellan held a ball and [[Content/Collateral Damage]] were one of the performances under the alias [[Content/Peter Snuffencougher]] and [[Content/Peter's Players and Performers]]. 
He has recently engaged [[Content/Perry Stinkmire]] to transport a crate with unknown contents to the [[Content/Lighthouse]] manned by [[Content/Major Ursa]].
Friends with [[Content/Eda Oweland]]
A member of the [[Content/Traditionists]]
Enjoyed the performance of [[Content/Peter's Players and Performers]].
*He met with [[Content/Cleveland Faskettel]] and hinted that he has dealings with [[Content/Guardian of Time]] and [[Content/Fizzlepop]] in events not on this world.  He wants [[Content/Cleveland Faskettel]] to work for him as an agent, but [[Content/Cleveland Faskettel]] has refused, but did agree to deliver a crate of unknown goods to [[Content/Major Ursa]] on [[Content/Abbey Island]].*


*Gellan (NE male human noble) is a well-spoken, dapper older gentleman with a neatly trimmed beard and a fancy wardrobe. With his cunning instincts, he has positioned his family to become the most prominent merchants in town, but he now faces an intractable problem. Gellan made his fortune through smuggling, his textile and lumber exports serving as a cover for his illegal activities. When Saltmarsh was a sleepy backwater, he could operate with impunity. Now that Saltmarsh has attracted attention from the outside world, he sees business growing more difficult and less profitable.

*Over the years, Gellan has cultivated relationships with a number of contacts among the Sea Princes. His ships move illicit goods, including slaves, between their realm and Keoland. Gellan takes care to keep this side of his business quiet, since any hint of involvement with slave traders would mean the end of his days in Saltmarsh, if not his life.

*Gellan seeks to keep his smuggling cartel functioning with as little interference as possible. Having a seat on the council puts him in a perfect position to maintain his business while supporting all aspects of the traditionalists’ agenda. His popularity in the faction is second only to that of Eda Oweland.

*Because Gellan is the wealthiest man in town, he garners a great deal of popular support from the many feasts, entertainments, and other diversions he supports with expenditures and donations. He pretends to care little for the daily functions of the council, defaulting to throw his support behind Eda’s position. In truth, this deference is a ruse he uses to mask his efforts to shield his smuggling operation.*

*Personality Traits. Gellan loves to play the role of the foppish dandy. He enjoys fine wine, good food, and the latest fashions. He is a patron of the arts and spends lavishly to support festivals, plays, and concerts.*

*Ideal. For Gellan, beauty and elegance are everything. He derives great enjoyment from watching the town enjoy his events.

*Bond. Gellan values his reputation above all else. He wants to be admired by the people of Saltmarsh.

*Flaw. Greed colors every action Gellan takes. He can’t turn down a chance to turn a profit, even if it means breaking the law. Gellan secretly believes that even if he is caught, he can spend his way back into the town’s good graces by throwing the biggest, most extravagant festival Saltmarsh has ever seen.

#NPC 