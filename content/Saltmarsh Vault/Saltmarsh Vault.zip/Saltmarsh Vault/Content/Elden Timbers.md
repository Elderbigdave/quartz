A forest gnome.
A warlock
Wants to retake his villiage
Has a pet 
A member of [[Content/Collateral Damage]]
Missing his physical hands but possesses spiritual hands.
A servant of the [[Content/Limbless One]]


#CHARACTER 
