# DISGUISE SELF

[1st](https://a5e.tools/spell-levels/first)-level ([illusion](https://a5e.tools/spells/illusion)[arcane](https://a5e.tools/spells/arcane)[obscurement](https://a5e.tools/spells/obscurement))
Class(es)
[Artificer](https://a5e.tools/classes/artificer)
[bard](https://a5e.tools/classes/bard)
[sorcerer](https://a5e.tools/classes/sorcerer)
[wizard](https://a5e.tools/classes/wizard)
Casting Time
[1 Action](https://a5e.tools/spell-casting-times/1-action)
Range
[Self](https://a5e.tools/spell-ranges/self)
Components:
[V](https://a5e.tools/spell-components/vocalized)[S](https://a5e.tools/spell-components/seen)
Duration:
[1 hour](https://a5e.tools/spell-durations/1-hour)

Until the spell ends or you use an action to dismiss it, you and your gear are cloaked by an illusory disguise that makes you appear like another creature of your general size and body type, including but not limited to: your heritage, 1 foot of height, weight, clothing, tattoos, piercings, facial features, hair style and length, skin and eye coloration, sex and any other distinguishing features. You cannot disguise yourself as a creature of a different size category, and your limb structure remains the same; for example if you're bipedal, you can’t use this spell to appear as a quadruped. 

The disguise does not hold up to physical inspection. A creature that tries to grab an illusory hat, for example, finds its hand passes straight through the figment. To see through your disguise without such an inspection, a creature must use its action to make an Investigation check against your spell save DC.

Cast at Higher Levels

When using a spell slot of 3rd-level or higher, this spell functions as the original spell, except the spell’s duration is 10 minutes.

#SPELL 


