A gigantic alligator or crocodile like beast.
Slain by [[Content/Collateral Damage]] as a way to show the [[Content/Lizardfolk]] that they are brave and trustworthy.  

It took everything [[Content/Collateral Damage]] had to slay it.  [[Content/Elden Timbers]] struck the killing blow after having contributed little to the entire fight.

[[Content/Erb Faskettel]] claims to have been the one to kill this beast.

After killing [[Content/Thousand Tooth]], [[Content/Collateral Damage]] took the body and by using the spell [[Content/Tenser's Floating Disc]] dragged it through the swamp back to the [[Content/Lizardfolk]] home.

It was brought to the [[Content/Lizardfolk]] as a feasting gift.
Several hundred teeth were taken by [[Content/Perry Stinkmire]].


