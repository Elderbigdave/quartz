Captures pirate,  pooped himself.

#NPC 