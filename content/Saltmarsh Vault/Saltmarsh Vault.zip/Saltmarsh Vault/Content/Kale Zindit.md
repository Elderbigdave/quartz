A butler that also served as one of the judges at the [[Content/Primewater Audition]].

#NPC 
