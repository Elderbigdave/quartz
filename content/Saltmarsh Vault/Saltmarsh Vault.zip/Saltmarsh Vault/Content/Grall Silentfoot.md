Half orc of the Slithering tribe
Reads a lot


#CHARACTER 
