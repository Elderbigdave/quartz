Tucked at the edge of town and overlooking the sea, Eliander’s home provides him with a relaxing sanctuary away from the bustle of Saltmarsh. Eliander maintains the largest library in town; during his days of military service, he made a hobby of collecting rare books. If the characters need information on the history of Saltmarsh, they might find it in Eliander’s archives.

#LOCATION 
