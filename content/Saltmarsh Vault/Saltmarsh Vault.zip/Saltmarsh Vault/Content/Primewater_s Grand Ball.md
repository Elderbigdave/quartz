
There were many different performers that were performing at the ball.
[[Content/Peter's Players and Performers]] were to arrive by the side door at 7:00 pm and then perform at 8:00 pm.

After the performances all of the entertainers went to different areas of the grand hall to continue to entertain the party guests.  The party guests got to tip the performers.

[[Content/Peter's Players and Performers]] earned a total of:

| Amount | Currency | 
| -------- | -------- |  
| 3 | Platinum |  
| 42 | Gold |
|78|Silver|
|96|Copper|




