*Lanis thinks there is a trash monster that lives there or near there*

[[Content/Gellan Primewater]] maintains a large mansion right on the docks, allowing him to oversee his ships from his upstairs window. He sometimes leans out to shout orders or answer questions for his captains and crews, his booming voice echoing over the docks. The location of his house also makes it convenient for his smugglers; the crews slip goods through a secret entrance that leads to his mansion’s cellar.
