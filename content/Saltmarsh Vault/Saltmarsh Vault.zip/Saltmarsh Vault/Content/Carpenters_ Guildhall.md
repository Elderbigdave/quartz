Run by a snobby gnome named Jilar Kanklesten (N female gnome commoner), the carpenters’ guild has plenty of work building houses, assembling fish barrels, repairing docks, and much more. The whole building is a marvel of workmanship, made without a single nail. Jilar is obsessed with rare woods; she pays handsomely for adventurers to make expeditions in search of specific trees in the Hool Marshes, the Drowned Forest, and the Dreadwood. Roll a d8 and consult the table below if the characters seek work from her.

| d8 | Object|
|----|-------|
|1|The branch of a tree used to hang a murderer|
|2|Splinters from a tree struck by lightning|
|3|A shard of a treant’s bark, given freely|
|4|A wooden stake used to impale a vampire|
|5|Tendrils harvested from a shambling mound|
|6|Deck planks stolen from a pirate ship|
|7|Log taken from the Hool Marshes, transported in swamp water|
|8|Wood from a shipwreck|


#LOCATION 