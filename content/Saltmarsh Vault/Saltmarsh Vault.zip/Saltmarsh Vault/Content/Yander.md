A servant at [[Content/Primewater Mansion]].
He was present at the [[Content/Primewater Audition]].

#NPC 
