An alias of [[Content/Cleveland Faskettel]].
This alias is a performer and the leader and agent for the entertainment troope [[Content/Peter's Players and Performers]].