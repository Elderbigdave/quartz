A veteran guard of [[Content/Eliander Fireborn]]
Is a bigot against gnomes.
Goes by Fred.

#NPC 
