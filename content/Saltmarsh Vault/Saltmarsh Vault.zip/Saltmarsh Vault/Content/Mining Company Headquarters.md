[[Content/Fizzlepop]]'s lab is located below.  [[Content/Lanis]] has some access here.



Once a mansion owned by a local noble family, this building was purchased by the crown and serves as the dwarven mining company’s headquarters in Saltmarsh. Manistrad Copperlocks stays here when she must do business in town; otherwise, several dwarf clerks work here during the day, logging deliveries at the docks to be transported to the mine and arranging for the processed ore to be loaded on trade ships bound for distant ports.

Rumors abound of a vault hidden beneath the building. In the cellar, the dwarves have dug a chamber in the earth that is sealed with a heavy iron door and a fine lock (requiring a successful DC 25 Dexterity check with thieves’ tools to pick). The dwarves keep their funds here — about 1,000 gp in coins and gems, guarded by four suits of [animated armor](https://www.dndbeyond.com/monsters/16786-animated-armor) and a [rug of smothering](https://www.dndbeyond.com/monsters/17000-rug-of-smothering) left in the vault. The constructs do not attack dwarves and can be disabled for 10 minutes if the command word “Tatalot” is spoken to them. Manistrad and her close advisors know the command word.

#LOCATION 
