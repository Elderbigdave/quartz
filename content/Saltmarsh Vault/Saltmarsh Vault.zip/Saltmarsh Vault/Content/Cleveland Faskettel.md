A gnome of a certain disreputable reputation.  Over 100 years ago he stole his family's fortune.  He thought he was using it in a wise investment only to loose it all in a scam.  Because of this embarrassment he left home and will not return until he can replace the money.

He is the older brother of brother of [[Content/Erb Faskettel]].  
He is a member of [[Content/Collateral Damage]]
Cleveland Faskettel is the true identity of [[Content/Perry Stinkmire]], [[Content/Peter Snuffencougher]], [[Content/Philip Strickhousen]], [[Content/Preston Successor VIII]], [[Content/Paul Shooterfisk]]

#CHARACTER 





