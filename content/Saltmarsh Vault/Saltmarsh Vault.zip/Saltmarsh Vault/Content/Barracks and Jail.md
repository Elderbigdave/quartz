Built on a low hill, the Saltmarsh barracks are also its jail. It is one of the few structures in Saltmarsh with an underground level. The jailer, Kraddok Stonehorn (LG male human gladiator), is an old comrade of Eliander. He is a stickler for the rules, and Eliander trusts him with his life.

The jail in the cellar consists of two sections. A single large chamber holds drunks, brawling fishers, and other troublemakers who need to cool off for a few nights. The lock is high quality (requiring a successful DC 20 Dexterity check with thieves’ tools to pick), and the door is built of stout wood with a small window to allow guards to check in on their charges.

A side passage holds six individual cells with higher-quality locks (each requiring a successful DC 25 Dexterity check with thieves’ tools to pick) and solid doors that lack windows. One cell was long ago warded against both teleportation and divination magic. Spellcasters are kept here, blindfolded and manacled. Occasionally Eliander uses this cell to conduct meetings that require the utmost secrecy.

The jail is used to hold prisoners with sentences of up to a year, but those facing longer terms or sentenced to hard labor are transferred to the prison at Seaton, a larger, heavily fortified port to the east.

At any given time, 2d4 guards, led by a veteran, keep watch here.

#LOCATION 