Location #30 on the map for [[Saltmarsh City]]

Two enormous runestones stand on this island. In ages past, a siren was chained to the stones here and sacrificed by an evil human tribe as an offering to the sea. Since then, the fishing in the region has flourished. The siren’s spirit was captured in the stones, and her captivating song continues to echo through the weave and draw fish to the area. The siren’s sisters and allies, among them a powerful djinn, have scoured the planes in search of her spirit for centuries.

#LOCATION 
