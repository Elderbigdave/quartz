Half-elf brother of [[Content/Lanis]].
A [[Content/Druid]].
Can harvest herbs and supplies.
Can craft potions.

#CHARACTER 
