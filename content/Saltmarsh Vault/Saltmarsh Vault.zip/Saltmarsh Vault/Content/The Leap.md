The Leap is an outcropping of rock nearly a hundred feet above the churning water below. Several stone benches stand near this precipitous edge, and a few stone markers sit in the tall grass nearby.

Traditionally, the people of Saltmarsh leap from the cliffs into the water below when a loved one drowns at sea. The jump is usually not fatal; the water below the Leap is free of rocks, and it is a short swim back to dry land.

#LOCATION 

