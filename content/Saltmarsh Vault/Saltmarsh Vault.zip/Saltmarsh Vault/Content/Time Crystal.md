These crystals stabilize time and space but can be used for nefarious purposes and must be protected.
These are protected by the [[Content/Guardian of Time]] and the [[Content/Giff]] and possibly [[Content/Fizzlepop]].

