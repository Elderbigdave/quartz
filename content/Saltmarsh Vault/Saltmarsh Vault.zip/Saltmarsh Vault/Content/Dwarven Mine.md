Dwarven prospectors have toiled in this new mine for the past three years. Soldiers from Keoland’s royal army are stationed here for security alongside dwarf fighters from the Copperlocks clan. Travelers in need of shelter can rest on cots in the guard towers that surround the place, but only those with business related to the mine are allowed inside the gates without supervision.

The mine is a broad shaft dug into a steep hillside near the shore. Stone walls encompass it, with two guard towers overlooking the main gate and three other towers spaced evenly around the perimeter. The inner area contains a small village with warehouses, workshops, and houses, all erected during the time when the excavation was beginning and enormous amounts of stone became available for building.

The laborers also took the time to build a tavern, the Miner’s Respite, and spend their off hours there drinking, swapping tales, and gambling. The game of darts has become an obsession among the bored miners and soldiers, and anyone with real skill at the game has a chance of talking their way past the guard at the door to engage in a match.

#LOCATION 