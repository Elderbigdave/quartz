The Pirate ship that resupplies and trades through the [[Content/Haunted Mansion]].

Now operates as the personal ship of [[Content/Collateral Damage]] and is crewed by [[Content/Giff]] who were asked to do it by the [[Content/Guardian of Time]].

The ship is now called the [[Time Ghost]].




