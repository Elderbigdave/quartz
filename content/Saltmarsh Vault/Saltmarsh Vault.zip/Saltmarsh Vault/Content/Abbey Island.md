*We have stormed the island and have crossed the [[Content/Skull Dunes]] on our way to the Abbey.*

The island is the site of a small abbey that was long ago abandoned by the order of monks that built it. Since then, various outlaw gangs and monsters have claimed it as a lair.

An island surrounded by dangerous shoals with the only boat access on the southern tip of the island where the [[Content/Skull Dunes]] are located. 



#LOCATION
