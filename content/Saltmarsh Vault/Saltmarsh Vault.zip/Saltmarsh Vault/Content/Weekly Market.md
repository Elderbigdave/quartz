Built around the first well dug for the fishers in the town’s early days is a large market square where merchants of all descriptions gather on the first day of each week to sell their wares. Initially established to sell fish, the market has grown to include a wide variety of goods. The center area of the square contains a dozen long tables where shoppers can eat communally. Items from the Player’s Handbook costing up to 150 gp are available for purchase here.

#LOCATION 
