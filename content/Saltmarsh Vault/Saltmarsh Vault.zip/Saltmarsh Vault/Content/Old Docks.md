The Old Docks of [[Saltmarsh City]].
Can only support small boats
The Dockmaster here is [[Content/Argin Thundercreek]].

#LOCATION 

