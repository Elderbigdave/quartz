A huge creature that looks like the hybrid between an [[Content/Treant]] and an [[Content/Earth Elemental]].

#NPC 

