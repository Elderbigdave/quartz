A mad artificer of amazing skill and power.  He is the mentor of [[Content/Lanis]] and is caring for the mother of [[Content/Lanis]] and [[Content/Rolin]].

He is a mad genius who has dropped hints that he has knowledge of and participates in events in places other than this world.

#NPC 