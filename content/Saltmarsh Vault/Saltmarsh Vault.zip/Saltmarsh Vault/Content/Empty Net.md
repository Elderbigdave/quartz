Partially supported by stilts driven into the harbor waters, this rickety tavern is purportedly a haven for smugglers, mercenaries, assassins and even pirates. The owner, Kreb Shenker (NE male human thug), takes coin from anyone and asks no questions. Troublemakers are thrown out the door, over the railing, and into the reeking harbor. Characters looking to carouse find this the best place for a rowdy night of drinking and brawling. The town guard comes here only if called.

Kreb works with Gellan Primewater to screen prospective buyers and sellers for smuggled wares. He also recruits local toughs and sailors for Gellan’s ventures, but he prefers those who are business-minded and less likely to cause trouble.

#LOCATION 
