The light house near [[Saltmarsh City]] and [[Content/Abbey Island]].
Home of [[Content/Major Ursa]].

#LOCATION 



