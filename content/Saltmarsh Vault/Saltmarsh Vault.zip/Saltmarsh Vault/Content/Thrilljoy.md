An alcoholic beverage that turns people into [[Content/Space Clowns]].
