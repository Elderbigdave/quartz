This 60-foot-tall tower was the first defensive building of Saltmarsh, and it still serves as an armory and lookout as well as the official base of the town guard. Eliander spends most of his time here in his duties as commander of the guard. He sometimes has need for adventurers, and at such times he posts jobs on a board hanging by the tower’s entrance. Roll a d6 and consult the table below to determine the nature of an available task.

| d6 | Goal | Foes | Location |
|----|------|------|----------|
|1|Recover Stolen Goods|Goblins|Hool Marshes|
|2|Apprehend a wanted criminal|Wild Beasts|Hool Marshes|
|3|Rescue a captive|Bandits|Dreadwood|
|4|Defeat a threat|Cultist|Dreadwood|
|5|Find a lost patrol|Bullywugs|Drowned Forest|
|6|Scout a dangerous area|Undead|Azure Sea|


#LOCATION 
