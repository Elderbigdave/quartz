The dock master of the [[Content/New Docks]].
He is a Half-Orc.

#NPC 