The New Docks of [[Saltmarsh City]].
Can support larger ships like the [[Content/Sea Ghost]].
The dock master is [[Content/Strongar Tallbender]].

#LOCATION 

