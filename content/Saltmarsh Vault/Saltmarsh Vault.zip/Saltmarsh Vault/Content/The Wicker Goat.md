Bearing the dubious honor of being the oldest tavern in town, the Wicker Goat is owned by Lankus Kurrid (NG male human guard), a retired officer of the Keoish army who caters to the dwarven miners and town guard. The two-story building has sleeping quarters for rent on the upper floor, usually sufficient to accommodate the slow stream of travelers making their way through Saltmarsh on the way to somewhere else.

Those who seek an audience with Manistrad can find her here when she’s not working at the mine. She sometimes has need for adventurers to help keep the mining operation secure. Roll a d6 and consult the table below to determine the nature of an available task.

| d6 | Task |
|------|----------|
|1|Guard a mining shaft that was recently attacked by duergar from the Underdark.|
|2|Escort supply wagons moving to and from Saltmarsh.|
|3|Explore a tunnel discovered in the mines that bears signs of troglodyte infestation.|
|4|Find a group of miners who went missing underground and may have been snatched by slavers.|
|5|Track down a thief who stole a shipment of expensive mining gear in Saltmarsh.|
|6|Locate the source of zombies and skeletons that have been sighted in the mines recently.|


#LOCATION 
