A leader in [[Saltmarsh City]]
A powerful contact of [[Content/Collateral Damage]]
Fought an Owlbear
Has an ornate peg leg.
Reports to the King who lives.....
Knows Ork language.
6 foot 5 inch Dragonborn

Has 2 veteran guards named [[Content/Fredrick]], [[Content/Robert]]


#NPC 

