The members of the town council are:
1. [[Content/Eda Oweland]]
2. [[Content/Gellan Primewater]]
3. [[Content/Eliander Fireborn]]
4. [[Content/Manistrad Copperlocks]].
5. [[Content/Anders Solomor]]